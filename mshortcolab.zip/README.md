# mshort-backend
MeetShort: Automatic Meeting Summarizer [Backend]
